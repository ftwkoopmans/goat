function r(){return new Worker(""+new URL("../workers/goat-58b3cda8.js",import.meta.url).href)}export{r as default};
