function r(){return new Worker(""+new URL("../workers/goat-4538ee89.js",import.meta.url).href)}export{r as default};
