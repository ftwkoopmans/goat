function r(){return new Worker(""+new URL("../workers/goat-37fc2722.js",import.meta.url).href)}export{r as default};
